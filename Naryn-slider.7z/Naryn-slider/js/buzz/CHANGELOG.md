# Buzz, a Javascript HTML5 Audio library

## CHANGE LOG

### Buzz 1.0.2 2011-07-04

* Fade effects wait for the sound to be ready before to start
* Loop and unloop methods now return the instance object

### Buzz 1.0.1 2011-07-01

* Fix arguments or array passed to Group constructor or methods
* Fix the default volume effect

### Buzz 1.0.0 2011-06-30

* First public release